﻿var video = document.getElementsByTagName("video");


//function playVideo() {
//    video[0].play();
//}

function playVideo()
{
    setTimeout(function () { video[0].play(); }, 1000);
};